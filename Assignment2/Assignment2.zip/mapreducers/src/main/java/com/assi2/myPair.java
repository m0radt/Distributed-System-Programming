package com.assi2;


public class myPair {
	Double x;
	String y;

	public myPair(Double x, String y)
	{
		this.x = x;
		this.y = y;
	}
    public Double getFirst(){
        return x;
    }
    public String getSecond(){
        return y;
    }
}

