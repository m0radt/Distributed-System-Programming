package com.assi1;

public class Names {
    public static String local2ManagerQueue = "local_to_manager_queue";
    public static String manager2WorkersQueue = "manager_to_worker_queue";
    public static String manager2LocalQueue = "manager_to_local_queue";
    public static String worker2ManagerQueue = "worker_to_manager_queue";
    public static String local2ManagerBucket = "local2managerbucket";
    public static String jarBucket = "jarbuck";

    
    
}
