package com.assi3;



public class Pair<K,V>  {
    public  K key;
    public  V value;

    Pair(K first, V second)
    {
        this.key=first;
        this.value=second;
    }

}
